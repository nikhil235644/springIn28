package demo.webApp.login;

import org.springframework.stereotype.Service;

@Service
public class AuthenticationService {
	public boolean authenticate(String username, String password){
		boolean isValidUserName=username.equalsIgnoreCase("Nik");
		boolean isValidPassword=password.equalsIgnoreCase("singh");
		
		return isValidUserName && isValidPassword;
	}

}
