package demo.webApp.hello;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
 public class SayhelloController {
	
	@RequestMapping("say-hello")
	@ResponseBody

	public String sayHello() {
		return "Hello! What are doing?";
	}
	
	@RequestMapping("say-hello-html")
	@ResponseBody

	public String sayHelloHtml() {
		StringBuffer sb = new StringBuffer();
		sb.append("<html>");
		sb.append("<head>");
		sb.append("<title>My first html page-changed</title>");
		sb.append("</head>");
		sb.append("<body>");
		sb.append("Html page Body-changed");
		sb.append("</body>");
		sb.append("</html>");
		return sb.toString();
		
	}
	
	
	//  /src/main/resources/META-INF/resources/WEB-INF/jsp/sayHello.jsp
	// Views-technology is jsp-java server pageS
	@RequestMapping("say-hello-jsp")

	public String sayHellojsp() {
		return "sayHello";
	}
}
